package com.example.sdev264_finalproject_longsworth

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mainLinkPrefs.setOnClickListener {
            var intent = Intent(this, PreferencesActivity::class.java)

            startActivity(intent)
        }

        mainLinkHelp.setOnClickListener {
            var intent = Intent(this, HelpActivity::class.java)

            startActivity(intent)
        }

        btnStartGame.setOnClickListener{
            var intent = Intent(this, SecondaryActivity::class.java)

            startActivity(intent)
        }
    }
}